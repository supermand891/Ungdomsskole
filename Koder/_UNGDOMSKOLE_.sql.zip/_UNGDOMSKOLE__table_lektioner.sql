
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `lektioner`
--
-- Oprettelse: 04. 09 2017 kl. 07:14:20
-- Seneste opdatering: 04. 09 2017 kl. 07:14:20
--

DROP TABLE IF EXISTS `lektioner`;
CREATE TABLE `lektioner` (
  `Lektion ID` int(11) NOT NULL COMMENT 'Eksempel: L001',
  `Starttidsunkt` time NOT NULL COMMENT 'Eksempel: 08:00',
  `Sluttidspunkt` time NOT NULL COMMENT 'Eksempel: 08:45'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
