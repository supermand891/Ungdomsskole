
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `telefon`
--
-- Oprettelse: 04. 09 2017 kl. 06:54:21
-- Seneste opdatering: 04. 09 2017 kl. 06:54:21
--

DROP TABLE IF EXISTS `telefon`;
CREATE TABLE `telefon` (
  `Telefon ID` int(11) NOT NULL COMMENT 'Eksempel: 0001 ',
  `Tlf. Hjem` varchar(20) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: +45 12 34 56 78',
  `Tlf. Mobil` varchar(20) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: +45 87 65 43 21'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
