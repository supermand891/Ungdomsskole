
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `personer hold`
--
-- Oprettelse: 31. 08 2017 kl. 09:14:40
-- Seneste opdatering: 31. 08 2017 kl. 09:14:40
--

DROP TABLE IF EXISTS `personer hold`;
CREATE TABLE `personer hold` (
  `Person` int(11) NOT NULL,
  `Hold` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
