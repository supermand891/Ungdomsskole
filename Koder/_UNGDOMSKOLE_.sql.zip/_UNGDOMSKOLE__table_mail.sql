
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `mail`
--
-- Oprettelse: 04. 09 2017 kl. 07:09:25
-- Seneste opdatering: 04. 09 2017 kl. 07:09:25
--

DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `Mail ID` int(11) NOT NULL COMMENT 'Eksempel: 0001 ',
  `Mail` varchar(128) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: example@email.com'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
