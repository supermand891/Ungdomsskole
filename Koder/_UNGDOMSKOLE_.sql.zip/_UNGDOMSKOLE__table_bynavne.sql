
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `bynavne`
--
-- Oprettelse: 04. 09 2017 kl. 07:04:37
-- Seneste opdatering: 04. 09 2017 kl. 07:04:37
--

DROP TABLE IF EXISTS `bynavne`;
CREATE TABLE `bynavne` (
  `By Nummer` int(11) NOT NULL COMMENT 'Eksempel: 3400',
  `By Navn` varchar(64) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Hillerød'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
