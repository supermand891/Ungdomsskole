
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `hold`
--
-- Oprettelse: 31. 08 2017 kl. 10:09:47
-- Seneste opdatering: 31. 08 2017 kl. 10:09:47
--

DROP TABLE IF EXISTS `hold`;
CREATE TABLE `hold` (
  `Hold ID` int(11) DEFAULT NULL COMMENT 'Eksempel: Fag001',
  `Fag` varchar(20) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Dansk',
  `Rum` varchar(20) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Rum001',
  `Lektioner` int(11) NOT NULL COMMENT 'Referere til Databasen Lektioner'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
