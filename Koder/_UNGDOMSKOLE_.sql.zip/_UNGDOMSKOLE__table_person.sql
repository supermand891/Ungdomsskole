
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `person`
--
-- Oprettelse: 31. 08 2017 kl. 10:02:14
-- Seneste opdatering: 31. 08 2017 kl. 10:02:14
--

DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `Person ID` int(11) NOT NULL COMMENT 'Eksempel: Esn001',
  `Fornavn` varchar(32) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Jens',
  `Efternavn` varchar(32) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Jensen',
  `Fødselsdag` date NOT NULL COMMENT 'Eksempel: 01/01-2001',
  `Køn` varchar(1) COLLATE utf8_danish_ci NOT NULL COMMENT 'M/D',
  `Aargang` varchar(9) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: 2015-2018',
  `Telefon` int(11) NOT NULL COMMENT 'Referere til Databasen Telefon',
  `Adresse` int(11) NOT NULL COMMENT 'Referere til Databasen Adresse',
  `Mail` int(11) NOT NULL COMMENT 'Referere til Databasen Mail'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
