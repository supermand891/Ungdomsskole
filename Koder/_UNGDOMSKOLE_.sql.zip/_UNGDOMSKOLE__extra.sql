
--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `adresse`
--
ALTER TABLE `adresse`
  ADD UNIQUE KEY `Adresse ID` (`Adresse ID`);

--
-- Indeks for tabel `hold`
--
ALTER TABLE `hold`
  ADD UNIQUE KEY `Hold ID` (`Hold ID`);

--
-- Indeks for tabel `lektioner`
--
ALTER TABLE `lektioner`
  ADD UNIQUE KEY `Lektion ID` (`Lektion ID`);

--
-- Indeks for tabel `mail`
--
ALTER TABLE `mail`
  ADD UNIQUE KEY `Mail ID` (`Mail ID`);

--
-- Indeks for tabel `person`
--
ALTER TABLE `person`
  ADD UNIQUE KEY `Person ID` (`Person ID`);

--
-- Indeks for tabel `personer hold`
--
ALTER TABLE `personer hold`
  ADD PRIMARY KEY (`Person`,`Hold`);

--
-- Indeks for tabel `telefon`
--
ALTER TABLE `telefon`
  ADD UNIQUE KEY `Telefon ID` (`Telefon ID`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `adresse`
--
ALTER TABLE `adresse`
  MODIFY `Adresse ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Eksempel: A001 ';
--
-- Tilføj AUTO_INCREMENT i tabel `lektioner`
--
ALTER TABLE `lektioner`
  MODIFY `Lektion ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Eksempel: L001';
--
-- Tilføj AUTO_INCREMENT i tabel `mail`
--
ALTER TABLE `mail`
  MODIFY `Mail ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Eksempel: 0001 ';
--
-- Tilføj AUTO_INCREMENT i tabel `person`
--
ALTER TABLE `person`
  MODIFY `Person ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Eksempel: Esn001';
--
-- Tilføj AUTO_INCREMENT i tabel `personer hold`
--
ALTER TABLE `personer hold`
  MODIFY `Person` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `telefon`
--
ALTER TABLE `telefon`
  MODIFY `Telefon ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Eksempel: 0001 ';