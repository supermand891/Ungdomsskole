
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `adresse`
--
-- Oprettelse: 04. 09 2017 kl. 07:01:30
-- Seneste opdatering: 04. 09 2017 kl. 07:01:30
--

DROP TABLE IF EXISTS `adresse`;
CREATE TABLE `adresse` (
  `Adresse ID` int(11) NOT NULL COMMENT 'Eksempel: A001 ',
  `Adresse Navn` varchar(128) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: Carlsbergvej 35 ',
  `By Nummer` varchar(4) COLLATE utf8_danish_ci NOT NULL COMMENT 'Eksempel: 3400'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci;
